#!/bin/bash
# Chay trong moi terminal cua container attacker khi lab bat dau:
# mo Firefox voi 1 tab: web Photo Sharing.
firefox http://webserver:8081 > /dev/null 2>&1 &
