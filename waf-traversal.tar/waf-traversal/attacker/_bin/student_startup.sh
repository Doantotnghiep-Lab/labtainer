#!/bin/bash
firefox http://webserver:8081 > /dev/null 2>&1 &
