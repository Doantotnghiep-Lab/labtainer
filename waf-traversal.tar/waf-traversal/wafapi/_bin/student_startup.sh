#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
(
  # Labtainers dat DISPLAY SAU khi chay script nay -> tu xac dinh DISPLAY
  sock=$(ls /tmp/.X11-unix/ 2>/dev/null | grep -m1 '^X[0-9]')
  [ -n "$sock" ] && export DISPLAY=":${sock#X}"
  sudo mount -o remount,size=1g /dev/shm
  for i in $(seq 1 120); do
    curl -s -o /dev/null http://127.0.0.1:5000/api/health && break
    sleep 2
  done
  firefox --new-instance http://127.0.0.1:5000/monitor
) > /tmp/waf-firefox.log 2>&1 &
fi
