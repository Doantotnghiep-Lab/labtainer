"""
run.py — Diem khoi chay web PhotoShare Lab.

Chay:  python run.py
Bien moi truong:
  VULN=1 (mac dinh) bat lo hong demo | VULN=0 che do an toan
  PORT=8081 (mac dinh)
"""
from app import app, config

if __name__ == "__main__":
    print("[WEB] PhotoShare Lab chay tai http://0.0.0.0:%d" % config.PORT)
    if config.VULN:
        print("[WEB] ⚠️  VULN=1: BAT lo hong co y (SQLi/XSS/Path Traversal) de demo lab.")
    else:
        print("[WEB] VULN=0: che do an toan.")
    app.run(host="0.0.0.0", port=config.PORT, debug=False, use_reloader=False)
