"""
db.py — Tang truy cap du lieu SQLite cho web chia se anh.

TAT CA truy van CSDL deu di qua file nay va dung SQLite (module `sqlite3` co san trong
Python, khong can may chu CSDL rieng) -> rat tien de demo chu de SQL Injection trong lab.

Moi ham truy van co san HAI phien ban:
  *_vuln(...)  -> NOI CHUOI truc tiep input vao cau SQL  => DINH SQL Injection (demo).
  *_safe(...)  -> dung tham so hoa (dau ?)                => an toan truoc SQL Injection.

Ham dieu phoi (login/search/find_user/...) se chon phien ban theo cong tac config.VULN.

Bang `users` co 9 cot -> payload UNION cho `/users/<id>` (SELECT *) can dung 9 cot.
Truy van tim kiem chi lay 4 cot -> payload UNION cho tim kiem can dung 4 cot.
(Chi tiet payload xem README.)
"""
import os
import sqlite3

from . import config
from . import seed_data


# --------------------------------------------------------------------------------------
# Ket noi
# --------------------------------------------------------------------------------------
def get_conn():
    """Mo ket noi SQLite moi. row_factory=Row de truy cap cot theo ten."""
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# --------------------------------------------------------------------------------------
# Khoi tao + nap du lieu mau (goi luc khoi dong, build lai sach moi lan chay lab)
# --------------------------------------------------------------------------------------
SCHEMA = """
DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS photos;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL,          -- plaintext: diem yeu CO Y de SQLi lam lo mat khau
    first_name  TEXT,
    last_name   TEXT,
    location    TEXT,
    bio         TEXT,                   -- be mat Stored XSS (hien o trang profile)
    occupation  TEXT,
    role        TEXT DEFAULT 'user'
);

CREATE TABLE photos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    file_name   TEXT NOT NULL,
    caption     TEXT,
    date_time   TEXT
);

CREATE TABLE comments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    photo_id    INTEGER NOT NULL,
    user_id     INTEGER NOT NULL,
    body        TEXT,                   -- be mat Stored XSS (hien o trang xem anh)
    date_time   TEXT
);
"""


def init_db():
    """Tao lai schema va nap du lieu mau. Dung tham so hoa khi SEED (seed khong phai lo hong)."""
    os.makedirs(os.path.dirname(config.DB_PATH), exist_ok=True)
    conn = get_conn()
    try:
        conn.executescript(SCHEMA)

        # Nap users
        uid_by_username = {}
        for (username, password, first, last, loc, bio, occ, role) in seed_data.USERS:
            cur = conn.execute(
                """INSERT INTO users
                   (username, password, first_name, last_name, location, bio, occupation, role)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (username, password, first, last, loc, bio, occ, role),
            )
            uid_by_username[username] = cur.lastrowid

        # Nap photos
        pid_by_file = {}
        for (owner, file_name, caption, dt) in seed_data.PHOTOS:
            cur = conn.execute(
                """INSERT INTO photos (user_id, file_name, caption, date_time)
                   VALUES (?, ?, ?, ?)""",
                (uid_by_username[owner], file_name, caption, dt),
            )
            pid_by_file[file_name] = cur.lastrowid

        # Nap comments
        for (photo_file, author, body, dt) in seed_data.COMMENTS:
            conn.execute(
                """INSERT INTO comments (photo_id, user_id, body, date_time)
                   VALUES (?, ?, ?, ?)""",
                (pid_by_file[photo_file], uid_by_username[author], body, dt),
            )

        # CHE DO LABTAINER: neu co LAB_FLAG_FILE thi dat mat khau 'admin' = FLAG.
        # Nho vay FLAG chi lay duoc khi DUMP bang users qua SQL Injection (UNION / sqlmap).
        # Dung tham so hoa o day vi SEED khong phai la diem lo hong.
        _seed_lab_flag(conn)

        conn.commit()
    finally:
        conn.close()


def _seed_lab_flag(conn):
    """Doc FLAG tu config.LAB_FLAG_FILE (Labtainer sinh ra) va gan vao mat khau tai khoan admin.
    Khong dat bien / khong doc duoc file -> giu nguyen mat khau mau (web doc lap van chay binh thuong)."""
    flag_file = getattr(config, "LAB_FLAG_FILE", "")
    if not flag_file:
        return
    try:
        with open(flag_file, "r", encoding="utf-8", errors="replace") as fh:
            lines = [ln.strip() for ln in fh.read().splitlines() if ln.strip()]
        flag = lines[0] if lines else ""
    except OSError:
        return
    if flag:
        conn.execute("UPDATE users SET password = ? WHERE username = 'admin'", (flag,))


# ======================================================================================
# 1) DANG NHAP  — POST /login  (payload nam trong THAN FORM)
# ======================================================================================
def login_vuln(conn, username, password):
    """
    ❌ CO LO HONG: noi thang username/password vao cau SQL.
       Payload vi du (o o Username), Password go gi cung duoc:
         ' OR 1=1 --          -> tra ve tat ca user, dang nhap vao user dau tien (admin)
         admin' --            -> dang nhap dung tai khoan admin, KHONG can mat khau
    Tra ve (row|None, sql_da_chay).
    """
    sql = (
        "SELECT * FROM users "
        "WHERE username = '" + username + "' AND password = '" + password + "'"
    )
    try:
        rows = conn.execute(sql).fetchall()
    except sqlite3.Error as e:
        return None, sql + "   /* LOI SQL: " + str(e) + " */"
    return (rows[0] if rows else None), sql


def login_safe(conn, username, password):
    """✅ AN TOAN: tham so hoa (dau ?). Input khong the thoat ra khoi chuoi SQL."""
    sql = "SELECT * FROM users WHERE username = ? AND password = ?"
    rows = conn.execute(sql, (username, password)).fetchall()
    return (rows[0] if rows else None), sql


# ======================================================================================
# 2) TIM KIEM NGUOI DUNG  — GET /?q=  (o tim kiem trang chu; payload nam trong QUERY STRING)
#    Cau SQL chi lay 4 cot -> payload UNION can dung 4 cot, vi du:
#      ' UNION SELECT id, username, password, occupation FROM users --
#    -> lo username + password cua moi nguoi dung.
# ======================================================================================
def search_vuln(conn, q):
    """❌ CO LO HONG: noi thang q vao menh de LIKE. Tra ve (rows, sql)."""
    sql = (
        "SELECT id, username, first_name, last_name FROM users "
        "WHERE first_name LIKE '%" + q + "%' "
        "OR last_name LIKE '%" + q + "%' "
        "OR username LIKE '%" + q + "%'"
    )
    try:
        rows = conn.execute(sql).fetchall()
    except sqlite3.Error as e:
        return [], sql + "   /* LOI SQL: " + str(e) + " */"
    return rows, sql


def search_safe(conn, q):
    """✅ AN TOAN: tham so hoa. Ky tu dac biet trong q chi la du lieu, khong phai cau lenh."""
    like = "%" + q + "%"
    sql = (
        "SELECT id, username, first_name, last_name FROM users "
        "WHERE first_name LIKE ? OR last_name LIKE ? OR username LIKE ?"
    )
    rows = conn.execute(sql, (like, like, like)).fetchall()
    return rows, sql


# ======================================================================================
# 3) LAY USER THEO ID  — GET /users/<id>  (payload nam trong DUONG DAN / path segment)
#    SELECT * -> payload UNION can dung 9 cot (bang users co 9 cot), vi du:
#      ' UNION SELECT id,username,password,first_name,last_name,location,bio,occupation,role FROM users --
# ======================================================================================
def find_user_vuln(conn, uid):
    """❌ CO LO HONG: noi thang uid vao cau SQL, khong kiem tra dinh dang. Tra ve (row|None, sql)."""
    sql = "SELECT * FROM users WHERE id = '" + str(uid) + "'"
    try:
        rows = conn.execute(sql).fetchall()
    except sqlite3.Error as e:
        return None, sql + "   /* LOI SQL: " + str(e) + " */"
    return (rows[0] if rows else None), sql


def find_user_safe(conn, uid):
    """✅ AN TOAN: tham so hoa + ep kieu."""
    sql = "SELECT * FROM users WHERE id = ?"
    rows = conn.execute(sql, (uid,)).fetchall()
    return (rows[0] if rows else None), sql


# --------------------------------------------------------------------------------------
# Cac ham phu tro KHONG dinh lo hong (luon tham so hoa) — dung cho hien thi binh thuong
# --------------------------------------------------------------------------------------
def list_users(conn):
    return conn.execute(
        "SELECT id, username, first_name, last_name, occupation, location FROM users ORDER BY id"
    ).fetchall()


def get_user_by_id(conn, uid):
    return conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()


def get_user_by_username(conn, username):
    return conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()


def create_user(conn, username, password, first, last, location, bio, occupation):
    """Dang ky nguoi dung moi (tham so hoa -> dang ky khong phai diem SQLi)."""
    cur = conn.execute(
        """INSERT INTO users (username, password, first_name, last_name, location, bio, occupation, role)
           VALUES (?, ?, ?, ?, ?, ?, ?, 'user')""",
        (username, password, first, last, location, bio, occupation),
    )
    conn.commit()
    return cur.lastrowid


def list_photos_of_user(conn, uid):
    return conn.execute(
        "SELECT * FROM photos WHERE user_id = ? ORDER BY id", (uid,)
    ).fetchall()


_PHOTO_SELECT = (
    "SELECT p.id, p.file_name, p.caption, p.date_time, "
    "u.username AS owner_username, u.first_name, u.last_name "
    "FROM photos p JOIN users u ON u.id = p.user_id"
)


def list_all_photos(conn):
    return conn.execute(_PHOTO_SELECT + " ORDER BY p.id").fetchall()


def search_photos(conn, q):
    """Tim anh theo tieu de (tham so hoa)."""
    return conn.execute(
        _PHOTO_SELECT + " WHERE p.caption LIKE ? ORDER BY p.id", ("%" + q + "%",)
    ).fetchall()


def get_photo(conn, photo_id):
    return conn.execute("SELECT * FROM photos WHERE id = ?", (photo_id,)).fetchone()


def list_comments_of_photo(conn, photo_id):
    return conn.execute(
        """SELECT c.id, c.body, c.date_time,
                  u.username AS author_username, u.first_name, u.last_name
           FROM comments c JOIN users u ON u.id = c.user_id
           WHERE c.photo_id = ? ORDER BY c.id""",
        (photo_id,),
    ).fetchall()


def add_comment(conn, photo_id, user_id, body, date_time):
    """Luu binh luan (tham so hoa). Noi dung `body` co the chua payload XSS -> Stored XSS
       xay ra o TANG HIEN THI (template), khong phai o tang CSDL."""
    conn.execute(
        "INSERT INTO comments (photo_id, user_id, body, date_time) VALUES (?, ?, ?, ?)",
        (photo_id, user_id, body, date_time),
    )
    conn.commit()
