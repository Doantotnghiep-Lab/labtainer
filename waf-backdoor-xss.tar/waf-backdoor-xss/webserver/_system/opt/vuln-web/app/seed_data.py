"""
seed_data.py — Du lieu mau goc cho web chia se anh (hoan toan moi, tu dat ra).

Tai khoan mau (username / password):
    admin  / S3cr3t_Admin!      (role=admin)
    alice  / password123
    bob    / qwerty
    carol  / sunshine
    dave   / letmein
    eve    / dragon
"""

# (username, password, first_name, last_name, location, bio, occupation, role)
USERS = [
    ("admin", "S3cr3t_Admin!", "Quan", "Tri", "Ha Noi, VN",
     "Quan tri vien he thong chia se anh.", "Administrator", "admin"),
    ("alice", "password123", "Alice", "Nguyen", "Da Nang, VN",
     "Thich chup anh bien va nui.", "Photographer", "user"),
    ("bob", "qwerty", "Bob", "Tran", "Sai Gon, VN",
     "Dan phuot, me anh thanh pho ve dem.", "Traveler", "user"),
    ("carol", "sunshine", "Carol", "Le", "Hue, VN",
     "Yeu mau sac va anh sang tu nhien.", "Designer", "user"),
    ("dave", "letmein", "Dave", "Pham", "Can Tho, VN",
     "Chup anh phong canh song nuoc.", "Engineer", "user"),
    ("eve", "dragon", "Eve", "Vu", "Hai Phong, VN",
     "Suu tap anh hoang hon.", "Student", "user"),
]

# (owner_username, file_name, caption, date_time)
PHOTOS = [
    ("alice", "mountain.png",  "Binh minh tren nui", "2024-03-01 06:12:00"),
    ("alice", "mountain1.png",  "Suong som",          "2024-03-02 06:40:00"),
    ("bob",   "city.png",    "Pho dem ruc ro",     "2024-04-11 20:05:00"),
    ("bob",   "city1.png",      "Mua dem",            "2024-04-12 21:30:00"),
    ("carol", "forest1.png",    "Loi mon trong rung", "2024-05-20 09:00:00"),
    ("carol", "forest.png",     "Rung trong suong",   "2024-05-21 08:15:00"),
    ("dave",  "lake.png",      "Mat ho tinh lang",   "2024-06-03 17:45:00"),
    ("dave",  "lake1.png",    "Hoang hon ben ho",   "2024-06-04 18:10:00"),
    ("eve",   "desert1.png",    "Con duong sa mac",   "2024-07-15 16:20:00"),
    ("eve",   "desert.png",   "Doi cat",            "2024-07-16 16:55:00"),
    ("admin", "harbor1.png",   "Ben cang ve dem",    "2024-02-10 19:00:00"),
    ("admin", "harbor.png",   "Nhung con thuyen",   "2024-02-11 07:30:00"),
]

# (photo_file_name, author_username, body, date_time)
COMMENTS = [
    ("mountain.png", "bob",   "Anh dep qua!",                 "2024-03-01 08:00:00"),
    ("mountain.png", "carol", "Mau sac rat an tuong.",        "2024-03-01 09:15:00"),
    ("city.png",   "alice", "Thanh pho ve dem tuyet voi.",  "2024-04-11 22:00:00"),
    ("forest1.png",   "dave",  "Minh cung muon den day.",      "2024-05-20 10:30:00"),
    ("lake1.png",   "eve",   "Hoang hon dep me hon.",        "2024-06-04 19:00:00"),
    ("harbor1.png",  "alice", "Goc chup rat la.",             "2024-02-10 20:20:00"),
]
