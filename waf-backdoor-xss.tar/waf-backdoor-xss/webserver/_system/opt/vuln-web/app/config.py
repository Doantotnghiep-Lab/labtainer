"""
config.py — Cau hinh tap trung cho ung dung lab.

Moi lo hong deu nam SAU cong tac moi truong VULN:
  VULN=1  -> BAT lo hong co y (SQLi / XSS / Path Traversal) de demo trong bai lab.
  VULN=0  -> web chay o che do AN TOAN (truy van tham so hoa, escape output, chan traversal).

Chi dung trong moi truong lab co lap (Labtainer, offline). KHONG trien khai ra mang that.
"""
import os

# Cong tac lo hong. Mac dinh 1 (bat) de phuc vu demo lab; dat VULN=0 de so sanh truoc/sau.
VULN = os.environ.get("VULN", "1").strip() == "1"

# Cong HTTP cua web
PORT = int(os.environ.get("PORT", "8081"))

# Khoa phien (session). Trong lab dung khoa co dinh cho de tai lap.
SECRET_KEY = os.environ.get("SECRET_KEY", "lab-insecure-secret-key")

# Vi tri file CSDL SQLite. Build lai moi lan khoi dong de lab luon sach.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
DB_PATH = os.environ.get("DB_PATH", os.path.join(PROJECT_ROOT, "data", "app.db"))

# Thu muc chua anh (muc tieu cua Path Traversal). File nhay cam de ngoai thu muc nay.
IMAGES_DIR = os.path.join(BASE_DIR, "static", "images")

# CHE DO LABTAINER (tuy chon).
# Khi chay trong bai lab pentest-sqli, Labtainer sinh FLAG rieng cho tung sinh vien va ghi
# vao file nay (xem parameter.config: HASH_REPLACE). Neu bien LAB_FLAG_FILE duoc dat va doc
# duoc, mat khau cua tai khoan 'admin' se duoc gan = noi dung FLAG -> khai thac SQL Injection
# (UNION dump bang users) se lam LO ra FLAG. Khi chay web doc lap (khong dat bien nay) thi
# tai khoan admin giu mat khau mau binh thuong, khong anh huong gi.
LAB_FLAG_FILE = os.environ.get("LAB_FLAG_FILE", "").strip()

# ---- WAF: moi request (tru IP bao tri) phai duoc WAF API kiem tra truoc khi vao route ----
WAF_ENABLED = os.environ.get("WAF_ENABLED", "true").strip().lower() != "false"
WAF_API_URL = os.environ.get("WAF_API_URL", "http://127.0.0.1:5000").strip().rstrip("/")
WAF_TIMEOUT = float(os.environ.get("WAF_TIMEOUT_MS", "8000")) / 1000.0
# Danh sach IP cua mang bao tri (lap trinh vien). Request xuat phat tu day KHONG qua WAF.
WAF_TRUSTED_IPS = {ip.strip() for ip in os.environ.get("WAF_TRUSTED_IPS", "").split(",") if ip.strip()}

# ---- Bot quan tri (/admin/visit, chi bai waf-backdoor-xss) ----
BOT_FLAG_FILE = os.environ.get("BOT_FLAG_FILE", "/opt/secret/flagval.txt").strip()
# Chi gui cookie toi cac dich host:port nay (may thu thap tren may bao tri). Mac dinh rong = khong gui gi.
BOT_EXFIL_ALLOW = {x.strip() for x in os.environ.get("BOT_EXFIL_ALLOW", "").split(",") if x.strip()}
BOT_TIMEOUT = float(os.environ.get("BOT_TIMEOUT_MS", "5000")) / 1000.0
