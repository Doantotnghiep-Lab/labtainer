"""
waf_guard.py — Cong WAF cho web Flask (ban Python cua wafGuard.js ben Photo Sharing Express).

Moi request den web duoc gui sang WAF API (/api/check_request) TRUOC khi vao route:
  - WAF tra "allow"  -> cho di tiep
  - WAF tra "block"  -> 403:
        * trinh duyet (Accept: text/html) -> trang HTML "Request bi chan" (nhu ban Express)
        * client API (JSON)               -> 403 JSON {"error": "blocked_by_waf", ...}
  - WAF khong tra loi -> 503 (fail-closed), cung co 2 dang HTML/JSON

Ngoai le cua lap trinh vien (cua hau bao tri):
  Request xuat phat tu cac IP trong WAF_TRUSTED_IPS KHONG qua WAF.
  Moi request (ke ca request bo qua WAF) deu duoc ghi vao log dong "[REQ] ip=...".
"""
import html
import json
import urllib.request

from flask import Response, request

from . import config

LABELS = {
    "sqli": "SQL Injection",
    "xss": "Cross-Site Scripting (XSS)",
    "path-traversal": "Path Traversal",
}

PAGE_STYLE = """
 body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f1f5f9;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#0f172a}
 .box{background:#fff;max-width:560px;width:calc(100% - 32px);padding:32px;border-radius:14px;box-shadow:0 10px 30px rgba(15,23,42,.08);border-top:6px solid #dc2626}
 h1{margin:0 0 8px;font-size:22px} p{color:#475569;line-height:1.5}
 dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 14px;font-size:14px;margin:18px 0}
 dt{color:#64748b} dd{margin:0;font-family:ui-monospace,Consolas,monospace;word-break:break-all}
 a{color:#2563eb}
"""


def _request_url():
    qs = request.query_string.decode("utf-8", errors="replace")
    return request.path + ("?" + qs if qs else "")


def _request_body():
    if request.is_json:
        data = request.get_json(silent=True)
        return data if data else None
    if request.form:
        return request.form.to_dict()
    return None


def _ask_waf(payload):
    req = urllib.request.Request(
        config.WAF_API_URL + "/api/check_request",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=config.WAF_TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _wants_html():
    """Trinh duyet mo trang (khong phai goi API) -> tra trang HTML thay vi JSON."""
    if request.path.startswith("/api/"):
        return False
    best = request.accept_mimetypes.best_match(["application/json", "text/html"])
    return best == "text/html"


def _page(status, title, body_html, headers=None):
    doc = (
        '<!doctype html>\n<html lang="vi"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        "<title>%s</title><style>%s</style></head>"
        '<body><div class="box">%s</div></body></html>'
        % (html.escape(title), PAGE_STYLE, body_html)
    )
    return Response(doc, status=status, mimetype="text/html", headers=headers or {})


def _json(status, body, headers=None):
    return Response(
        json.dumps(body, ensure_ascii=False),
        status=status,
        mimetype="application/json",
        headers=headers or {},
    )


def _blocked(verdict):
    attack = verdict.get("attack_type")
    label = LABELS.get(attack, attack or "khong xac dinh")
    source = (verdict.get("matched_part") or {}).get("source")
    prob = verdict.get("malicious_probability")
    prob_txt = "%.2f %%" % (prob * 100) if prob is not None else "-"
    rid = verdict.get("request_id") or "-"
    headers = {"X-WAF-Status": "blocked", "X-WAF-Request-Id": rid}

    if _wants_html():
        body = (
            "<h1>⛔ Request đã bị WAF chặn</h1>"
            "<p>Hệ thống phát hiện nội dung độc hại trong yêu cầu của bạn nên đã từ chối truy cập.</p>"
            "<dl>"
            "<dt>Loại tấn công</dt><dd>%s</dd>"
            "<dt>Vị trí phát hiện</dt><dd>%s</dd>"
            "<dt>Xác suất độc hại</dt><dd>%s</dd>"
            "<dt>Mã request</dt><dd>%s</dd>"
            "</dl>"
            '<p><a href="/">← Về trang chủ</a></p>'
        ) % (html.escape(label), html.escape(source or "-"),
             html.escape(prob_txt), html.escape(rid))
        return _page(403, "Request bị chặn", body, headers)

    return _json(403, {
        "error": "blocked_by_waf",
        "message": "Request bi WAF chan: phat hien %s" % label,
        "attack_type": attack,
        "matched_source": source,
        "malicious_probability": prob,
        "request_id": verdict.get("request_id"),
    }, headers)


def _unavailable():
    headers = {"X-WAF-Status": "unavailable"}
    if _wants_html():
        body = (
            "<h1>WAF Detection API chưa sẵn sàng</h1>"
            "<p>Mọi request đều phải được API kiểm tra trước khi vào web, nhưng hiện không kết nối được "
            "tới <code>%s</code>. Hãy chắc chắn API đang chạy (model có thể mất vài giây để nạp) "
            "rồi tải lại trang.</p>"
        ) % html.escape(config.WAF_API_URL)
        return _page(503, "WAF chưa sẵn sàng", body, headers)
    return _json(503, {
        "error": "waf_unavailable",
        "message": "WAF chua san sang, request bi tu choi (fail-closed).",
    }, headers)


def install(app):
    @app.before_request
    def waf_guard():
        ip = request.remote_addr or "-"
        trusted = ip in config.WAF_TRUSTED_IPS
        url = _request_url()
        print("[REQ] ip=%s trusted=%s %s %s" % (ip, "yes" if trusted else "no", request.method, url),
              flush=True)

        if not config.WAF_ENABLED or trusted:
            return None

        payload = {
            "app": "photo-sharing",
            "method": request.method,
            "url": url,
            "body": _request_body(),
            "client_ip": ip,
        }
        try:
            verdict = _ask_waf(payload)
        except Exception as exc:  # timeout, khong ket noi, loi HTTP
            print("[WAF] API khong kha dung (%s) -> fail-closed, chan %s %s"
                  % (exc, request.method, url), flush=True)
            return _unavailable()

        if verdict.get("is_malicious"):
            return _blocked(verdict)

        return None
