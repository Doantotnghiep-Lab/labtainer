#!/bin/bash
echo $1 | sudo -S systemctl enable waf-api.service
echo $1 | sudo -S systemctl start waf-api.service
