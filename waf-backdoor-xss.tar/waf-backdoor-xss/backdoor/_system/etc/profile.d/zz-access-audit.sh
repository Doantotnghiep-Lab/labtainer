# Ghi nhat ky moi lan co dang nhap SSH tuong tac vao may bao tri.
if [ -n "$SSH_CONNECTION" ]; then
    echo "$(date '+%F %T') LOGIN user=$USER from=${SSH_CONNECTION%% *}" >> /var/log/backdoor/access.log 2>/dev/null
fi
